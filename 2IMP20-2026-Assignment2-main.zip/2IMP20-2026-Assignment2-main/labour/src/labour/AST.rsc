module labour::AST

/*
 * abstract syntax for LaBouR — mirrors the ecore metamodel but as
 * rascal algebraic data types.
 *
 * a few things worth noting:
 * - angularPos is only valid for side_holds inside circle volumes;
 *   the checker enforces this, not the grammar.
 * - missing required properties must be DETECTABLE by the checker, so
 *   defaults like 0 or (0,0) are not used: positions get noPosition()
 *   and required integers (depth, radius) are Maybe[int], where
 *   nothing() means "not written in the source".
 * - rotation = -1 is a sentinel meaning "not specified"; this one is safe
 *   because rotation is genuinely optional and -1 is not a legal angle.
 * - HoldLabel replaces the ecore boolean/int flags with clean constructors.
 */

import util::Maybe;

// colour is just a string; valid values are checked in Check.rsc
alias Colour = str;

data Position
  = cartesianPos(int x, int y)
  | angularPos(int angle)
  | noPosition()              // required position absent from the source
  ;

data HoldLabel
  = startHold(int n)   // n must be 1 or 2, checked in Check.rsc
  | endHold()
  | noLabel()
  ;

data Hold
  = hold(
      str          id,
      Position     position,
      str          shape,
      list[Colour] colours,    // at least one required
      int          rotation,   // -1 means absent
      HoldLabel    label
    )
  ;

data Volume
  = circleVolume(
      Position   pos,
      Maybe[int] depth,         // nothing() = missing, reported by checker
      Maybe[int] radius,        // nothing() = missing, reported by checker
      list[Hold] frontHolds,
      list[Hold] sideHolds
    )
  | triangleVolume(
      Position       pos,
      Position       extrusion,
      Maybe[int]     depth,     // nothing() = missing, reported by checker
      list[Position] corners,   // must be exactly 3, checked in Check.rsc
      list[Hold]     leftHolds,
      list[Hold]     rightHolds,
      list[Hold]     bottomHolds
    )
  ;

// a single entry is one hold id; a split entry is a parallel pair
data HoldEntry
  = singleEntry(str holdId)
  | splitEntry(str holdId1, str holdId2)
  ;

data BoulderingRoute
  = boulderingRoute(
      str             id,
      str             grade,
      Position        gridBasePoint,
      list[HoldEntry] holds
    )
  ;

data BoulderingWall
  = boulderingWall(
      str                   id,
      list[BoulderingRoute] routes,
      list[Volume]          volumes
    )
  ;
