module RunTests

import labour::Syntax;
import labour::Parser;
import labour::CST2AST;
import labour::AST;
import labour::Check;
import ParseTree;
import IO;
import Set;
import String;

loc TESTS = |project://labour/src/labour/tests|;

int main(list[str] args = []) {
    int failures = 0;

    println("=== valid example: expect parse OK and zero check errors ===");
    loc valid = TESTS + "valid_example.labour";
    try {
        start[Wall] pt = parseLaBouR(valid);
        BoulderingWall ast = cst2ast(pt);
        println("  parsed: wall \"<ast.id>\", <size(toSet(ast.routes))> route(s), <size(toSet(ast.volumes))> volume(s)");
        set[Message] msgs = checkBoulderRouteConfiguration(ast);
        if (isEmpty(msgs)) {
            println("  PASS: no well-formedness errors");
        } else {
            failures += 1;
            println("  FAIL: unexpected errors:");
            for (Message m <- msgs) println("    <m>");
        }
    } catch ParseError(loc l): {
        failures += 1;
        println("  FAIL: parse error at <l>");
    }

    println("=== invalid examples: each must parse but produce \>= 1 check error ===");
    loc invalidDir = TESTS + "invalid";
    for (loc f <- invalidDir.ls, f.extension == "labour") {
        try {
            start[Wall] pt = parseLaBouR(f);
            BoulderingWall ast = cst2ast(pt);
            set[Message] msgs = checkBoulderRouteConfiguration(ast);
            if (isEmpty(msgs)) {
                failures += 1;
                println("  FAIL <f.file>: checker reported no errors");
            } else {
                println("  PASS <f.file>:");
                for (Message m <- msgs) println("    <m.msg>");
            }
        } catch ParseError(loc l): {
            failures += 1;
            println("  FAIL <f.file>: parse error at <l>");
        }
    }

    println(failures == 0 ? "=== ALL TESTS PASSED ===" : "=== <failures> TEST(S) FAILED ===");
    return failures;
}
